#Technophile bud intern task-1

Landing page is an independent  web page that is mainly created to advertise. A Landing page can be creating html,css,js.
here I created the basic structure for pages such as adding Header,Footer, creating columns,section dividing along with creating a nav bar,background,styling,etc..